/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;
import java.util.Random;


public class RockPaperScissor {

    public static void main(String[] args) {
        Random ram = new Random();
        int num = 0;
        num = ram.nextInt(3) + 0;
        System.out.println(num);
        
        switch(num){
            case 0:
                System.out.println("piedra");
                break;
            case 1:
                System.out.println("papel");
                break;
            case 2:
                System.out.println("tijeras");
                break;
            default:
                System.out.println("error");          
    }
       
    }
}
